
A.REQUIREMENTS:

1.Before using this project you'll need certain python packages.

2.This project is so far supported in unix environment!Hence,Having unix environemnt is mandatory.

3.For classifying,tweets must be saved in some file(.txt preferably)

4.f python 2.7 is required .If it is not installed go to : https://www.python.org/downloads/
[Refer https://mail.python.org/pipermail/tutor/2002-March/012903.html]

5.Packages required :
(a)package : nltk
    install command in unix: sudo pip<2 or 3> install -U nltk
(b)package :easygui
    install command in unix: pip install easygui
(c)package Tkinter :
    install command in unix: pip install Tkinter    
    
6.change settings in your nautilus :
  a.go to preferences     
  b.go to behaviour tab
  c.under Executable text files go to "ask each time"
  d.close

  or
   open terminal and type sh run.sh
   
7.type python in terminal and in python prompt :
  a.import nltk
  b.nltk.download()
     
B.EXECUTING:
Double click run.sh ->choose run in teminal 

