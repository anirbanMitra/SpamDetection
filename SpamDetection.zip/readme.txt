before using this project you'll need certain python packages.
this project is so far supported in unix environment!Hence,Having unix environemnt is mandatory.
For classifying,tweets must be saved in some file(.txt preferably)
If python 2.7 is required .If it is not installed go to : https://www.python.org/downloads/
[Refer https://mail.python.org/pipermail/tutor/2002-March/012903.html]

1.Packages required :
package : nltk
    install command in unix: sudo pip install -U nltk
package :easygui
    install command in unix: pip install easygui
package Tkinter :
    install command in unix: pip install Tkinter    
    
2.change settings in your nautilus :
  1.go to preferences     
  2.go to behaviour tab
  3.under Executable text files go to "ask each time"
  4.close

  else
   open terminal and type sh run.sh
   
3.   
  
