echo "Which Approach you wanna use :\n(1)Naive bayesian\n(2)Decision Tree\n :"
read -p "Enter choice :" choice
if [ $choice = 1 ]
then
   python naiveBayes.py
else 
   python decisionTree.py
fi       
